package com.bignerdranch.android.pract21

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class new_contact : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_contact)
    }
}