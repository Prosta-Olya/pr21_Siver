package com.bignerdranch.android.pract21

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class contacts : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contacts)
    }
}